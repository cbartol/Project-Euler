#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <string.h>

#include "poker.h"

int getCardPosition(std::string card){
	char num = card[0];
	int _num, _suit;
	if(num == 'T'){
		_num = 10;
	} else if(num == 'J'){
		_num = 11;
	} else if(num == 'Q'){
		_num = 12;
	} else if(num == 'K'){
		_num = 13;
	} else if(num == 'A'){
		_num = 14;
	} else{
		_num = num - '0';
	}
	char suit = card[1];
	if(suit == 'H'){
		_suit = 13;
	} else if(suit == 'S'){
		_suit = 0;
	} else if(suit == 'D'){
		_suit = 26;
	} else{
		_suit = 39;
	}
	return (_num - 2) + _suit;
}

int main(){
	int p1count = 0;
	int p2count = 0;
	int draw = 0;
	int deck[52], hand1[5], hand2[5];
	init_deck( deck );
	char c = 'c';
	while(c != EOF){
		std::vector<std::string> input1;
		char card[2];
		for(int n = 0 ; n < 5 ; n++){
			card[0] = getchar();
			card[1] = getchar();
			getchar();
			input1.push_back(std::string(card));
		}
		std::vector<std::string> input2;
		for(int n = 0 ; n < 5 ; n++){
			card[0] = getchar();
			card[1] = getchar();
			c = getchar();
			input2.push_back(std::string(card));
		}
		
		for(int i = 0 ; i < 5 ; i++){
			hand1[i] = deck[getCardPosition(input1[i])];
		}
		for(int i = 0 ; i < 5 ; i++){
			hand2[i] = deck[getCardPosition(input2[i])];
		}
		int h1pts = eval_5hand(hand1);
		int h2pts = eval_5hand(hand2);
		if(h1pts < h2pts){
			p1count++;
		} else if(h1pts > h2pts){
			p2count++;
		} else {
			draw++;
		}
	}
		
	printf("Player1 won %d times\nPlayer2 won %d times\nDraws: %d\n", p1count, p2count, draw);
	system("pause");
	return 0;    
}
